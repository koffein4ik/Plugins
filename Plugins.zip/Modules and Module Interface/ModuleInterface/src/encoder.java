public interface encoder {
    public String encode(byte[] input);
    public byte[] decode(String input);
    public String getExtension();
}
