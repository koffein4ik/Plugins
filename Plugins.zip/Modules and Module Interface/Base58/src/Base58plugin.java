public class Base58plugin implements encoder{
    public String encode(byte[] input)
    {
        System.out.println("encode");
        String result = Base58.encode(input);
        return result;
    }

    public byte[] decode(String input)
    {
        System.out.println("decode");
        byte[] result = Base58.decode(input);
        return result;
    }

    public String getExtension()
    {
        return "base58";
    }
}
