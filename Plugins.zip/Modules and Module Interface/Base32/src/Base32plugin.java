public class Base32plugin implements encoder {
    public String encode(byte[] input)
    {
        Base32 encoder = new Base32("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567");
        return encoder.encodeInternal(input);
    }

    public byte[] decode(String input)
    {
        Base32 decoder = new Base32("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567");
        try {
            return decoder.decodeInternal(input);
        }
        catch (Exception ex)
        {
            System.out.println(ex.toString());
        }
        return null;
    }

    public String getExtension()
    {
        return "base32";
    }
}
