import java.util.Base64;

public class Base64plugin implements encoder {
    public String encode(byte[] input)
    {
        System.out.println("Encode");
        String result = Base64.getEncoder().encodeToString(input);
        return result;
    }

    public byte[] decode(String input)
    {
        System.out.println("Decode");
        byte[] decodedBytes = Base64.getDecoder().decode(input.getBytes());
        return decodedBytes;
    }

    public String getExtension()
    {
        return "base64";
    }
}
